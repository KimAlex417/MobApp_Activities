package com.example.hellosharedprefs;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    // UI elements
    private TextView mShowCountTextView;
    private Button mButtonBlack, mButtonRed, mButtonBlue, mButtonGreen;
    private Button mButtonCount, mButtonReset;

    // Keys for SharedPreferences
    private static final String COUNT_KEY = "count";
    private static final String COLOR_KEY = "color";

    // Current values
    private int mCount = 0;
    private int mColor;

    // SharedPreferences
    private SharedPreferences mPreferences;
    private static final String sharedPrefFile = "com.example.android.sharedpref";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        mShowCountTextView = findViewById(R.id.textview_count);
        mButtonBlack = findViewById(R.id.button_black);
        mButtonRed = findViewById(R.id.button_red);
        mButtonBlue = findViewById(R.id.button_blue);
        mButtonGreen = findViewById(R.id.button_green);
        mButtonCount = findViewById(R.id.button_count);
        mButtonReset = findViewById(R.id.button_reset);

        // Initialize default color (grey)
        mColor = getResources().getColor(R.color.default_background);
        mShowCountTextView.setBackgroundColor(mColor);

        // Initialize SharedPreferences
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        // Restore preferences
        mCount = mPreferences.getInt(COUNT_KEY, 0);
        mShowCountTextView.setText(String.valueOf(mCount));

        mColor = mPreferences.getInt(COLOR_KEY, mColor);
        mShowCountTextView.setBackgroundColor(mColor);

        // Set click listeners
        mButtonCount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countUp();
            }
        });

        mButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });

        View.OnClickListener colorListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeBackground(v);
            }
        };

        mButtonBlack.setOnClickListener(colorListener);
        mButtonRed.setOnClickListener(colorListener);
        mButtonBlue.setOnClickListener(colorListener);
        mButtonGreen.setOnClickListener(colorListener);
    }

    private void countUp() {
        mCount++;
        mShowCountTextView.setText(String.valueOf(mCount));
    }

    private void changeBackground(View view) {
        int id = view.getId();
        if (id == R.id.button_black) {
            mColor = getResources().getColor(android.R.color.black);
        } else if (id == R.id.button_red) {
            mColor = getResources().getColor(R.color.red);
        } else if (id == R.id.button_blue) {
            mColor = getResources().getColor(R.color.blue);
        } else if (id == R.id.button_green) {
            mColor = getResources().getColor(R.color.green);
        }
        mShowCountTextView.setBackgroundColor(mColor);
    }

    private void reset() {
        // Reset count
        mCount = 0;
        mShowCountTextView.setText(String.valueOf(mCount));

        // Reset color
        mColor = getResources().getColor(R.color.default_background);
        mShowCountTextView.setBackgroundColor(mColor);

        // Clear SharedPreferences
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.clear();
        editor.apply();
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Save preferences
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putInt(COUNT_KEY, mCount);
        editor.putInt(COLOR_KEY, mColor);
        editor.apply();
    }
}