package com.example.cnscresearchlibraryapp;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DocumentViewerActivity extends AppCompatActivity {
    private String documentId;
    private boolean isOwner;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        documentId = getIntent().getStringExtra("DOCUMENT_ID");
        isOwner = getIntent().getBooleanExtra("IS_OWNER", false);

        if (documentId == null) {
            finish();
            return;
        }

        checkDocumentAccess();
    }

    private void checkDocumentAccess() {
        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Document document = snapshot.getValue(Document.class);
                    if (document != null) {
                        if (isOwner || document.hasAccess(mAuth.getCurrentUser().getUid())) {
                            showDocument(document);
                        } else {
                            showAccessDenied();
                        }
                    }
                } else {
                    showDocumentNotFound();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showErrorLoading();
            }
        });
    }

    private void showDocument(Document document) {
        if (isOwner) {
            setContentView(R.layout.activity_abstract_upload);
            // Initialize owner view components
        } else {
            setContentView(R.layout.activity_abstract_view);
            // Initialize viewer view components
        }

        // Common initialization code for both views
        TextView titleView = findViewById(R.id.researchTitle);
        TextView dateView = findViewById(R.id.researchDate);
        TextView abstractView = findViewById(R.id.abstractContent);
        TextView figureCreditView = findViewById(R.id.figureCredit);

        titleView.setText(document.getTitle());
        dateView.setText("Published: " + document.getYear());
        abstractView.setText(document.getAbstractText());
        figureCreditView.setText("[Document uploaded by " + document.getUploaderName() + "]");
    }

    private void showAccessDenied() {
        Toast.makeText(this, "You don't have access to this document", Toast.LENGTH_LONG).show();
        finish();
    }

    private void showDocumentNotFound() {
        Toast.makeText(this, "Document not found", Toast.LENGTH_LONG).show();
        finish();
    }

    private void showErrorLoading() {
        Toast.makeText(this, "Error loading document", Toast.LENGTH_LONG).show();
        finish();
    }
}