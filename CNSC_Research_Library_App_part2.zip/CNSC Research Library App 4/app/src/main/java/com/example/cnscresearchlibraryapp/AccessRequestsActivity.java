package com.example.cnscresearchlibraryapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AccessRequestsActivity extends AppCompatActivity {
    private RecyclerView requestsRecyclerView;
    private String documentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_notification);

        documentId = getIntent().getStringExtra("DOCUMENT_ID");
        requestsRecyclerView = findViewById(R.id.notificationsRecyclerView);
        requestsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadAccessRequests();
    }

    private void loadAccessRequests() {
        DatabaseReference requestsRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId)
                .child("accessRequests");

        // Implement FirebaseRecyclerAdapter to show requests
        // Each item should have Approve/Reject buttons
    }

    private void approveRequest(String userId) {
        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.child("approvedViewers").child(userId).setValue(true);
        docRef.child("accessRequests").child(userId).removeValue();
    }
}