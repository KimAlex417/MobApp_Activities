package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DocumentAdapter adapter;
    private List<Document> documentList = new ArrayList<>();
    private TextView userNameTextView;
    private Button uploadsButton, savedButton;
    private View uploadsIndicator, savedIndicator;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        initializeViews();
        setupRecyclerView();
        loadUserProfile();
        setupButtonListeners();

        showUploads();
    }

    private void initializeViews() {
        userNameTextView = findViewById(R.id.textView14);
        recyclerView = findViewById(R.id.recyclerView);
        uploadsButton = findViewById(R.id.button7);
        savedButton = findViewById(R.id.button8);
        uploadsIndicator = findViewById(R.id.uploadsIndicator);
        savedIndicator = findViewById(R.id.savedIndicator);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DocumentAdapter(documentList, currentUser.getUid(), document -> {
            Intent intent = new Intent(ProfileActivity.this, DocumentViewerActivity.class);
            intent.putExtra("DOCUMENT_ID", document.getDocumentId());
            intent.putExtra("IS_OWNER", document.getUploaderUid().equals(currentUser.getUid()));
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);
    }

    private void loadUserProfile() {
        if (currentUser != null) {
            String displayName = currentUser.getDisplayName() != null ?
                    currentUser.getDisplayName() : "User";
            userNameTextView.setText("Name: " + displayName);
        }
    }

    private void setupButtonListeners() {
        findViewById(R.id.imageButton6).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.imageButton11).setOnClickListener(v ->
                startActivity(new Intent(this, NotificationActivity.class)));

        findViewById(R.id.floatingActionButton3).setOnClickListener(v -> {
            startActivity(new Intent(this, UploadActivity.class));
        });

        uploadsButton.setOnClickListener(v -> showUploads());
        savedButton.setOnClickListener(v -> showSaved());
    }

    private void showUploads() {
        uploadsButton.setSelected(true);
        savedButton.setSelected(false);
        if (uploadsIndicator != null) uploadsIndicator.setVisibility(View.VISIBLE);
        if (savedIndicator != null) savedIndicator.setVisibility(View.INVISIBLE);

        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("documents");
        dbRef.orderByChild("uploaderUid").equalTo(currentUser.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        documentList.clear();
                        for (DataSnapshot docSnapshot : snapshot.getChildren()) {
                            Document document = docSnapshot.getValue(Document.class);
                            if (document != null) {
                                document.setDocumentId(docSnapshot.getKey());
                                documentList.add(document);
                            }
                        }
                        adapter.notifyDataSetChanged();

                        if (documentList.isEmpty()) {
                            Toast.makeText(ProfileActivity.this,
                                    "No documents uploaded yet", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(ProfileActivity.this,
                                "Failed to load documents", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void showSaved() {
        uploadsButton.setSelected(false);
        savedButton.setSelected(true);
        if (uploadsIndicator != null) uploadsIndicator.setVisibility(View.INVISIBLE);
        if (savedIndicator != null) savedIndicator.setVisibility(View.VISIBLE);

        DatabaseReference savedRef = FirebaseDatabase.getInstance()
                .getReference("savedDocuments")
                .child(currentUser.getUid());

        savedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                documentList.clear();
                for (DataSnapshot docSnapshot : snapshot.getChildren()) {
                    String documentId = docSnapshot.getKey();
                    fetchDocumentDetails(documentId);
                }

                if (!snapshot.exists()) {
                    Toast.makeText(ProfileActivity.this,
                            "No saved documents yet", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this,
                        "Failed to load saved documents", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchDocumentDetails(String documentId) {
        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Document document = snapshot.getValue(Document.class);
                if (document != null) {
                    document.setDocumentId(documentId);
                    documentList.add(document);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ProfileActivity", "Error loading document details", error.toException());
            }
        });
    }
}