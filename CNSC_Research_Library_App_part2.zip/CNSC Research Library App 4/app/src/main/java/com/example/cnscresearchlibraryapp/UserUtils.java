package com.example.cnscresearchlibraryapp;

public class UserUtils {
    public static boolean isJuniorStudent(String year) {
        return year.equals("1st Year") || year.equals("2nd Year");
    }
}