package com.example.cnscresearchlibraryapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity implements DocumentAdapter.OnItemClickListener {
    private RecyclerView recyclerView;
    private DocumentAdapter adapter;
    private List<Document> allDocuments = new ArrayList<>();
    private List<Document> filteredDocuments = new ArrayList<>();
    private FirebaseUser currentUser;
    private EditText searchEditText;
    private Spinner programSpinner;
    private Spinner yearSpinner;
    private String initialSearchQuery = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // Get the initial search query from intent
        if (getIntent() != null && getIntent().hasExtra("SEARCH_QUERY")) {
            initialSearchQuery = getIntent().getStringExtra("SEARCH_QUERY");
        }

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeViews();
        setupRecyclerView();
        loadDocuments();
    }

    private void initializeViews() {
        ImageButton backButton = findViewById(R.id.imageButton2);
        searchEditText = findViewById(R.id.editText);
        ImageButton searchButton = findViewById(R.id.imageButton4);
        Button clearButton = findViewById(R.id.clearButton);
        programSpinner = findViewById(R.id.mySpinner);
        yearSpinner = findViewById(R.id.yearSpinner);

        // Set initial search query if it exists
        if (!initialSearchQuery.isEmpty()) {
            searchEditText.setText(initialSearchQuery);
        }

        backButton.setOnClickListener(v -> onBackPressed());

        backButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setAlpha(0.5f);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setAlpha(1.0f);
                    break;
            }
            return false;
        });

        searchButton.setOnClickListener(v -> {
            String query = searchEditText.getText().toString();
            applyFilters(query);

            // Hide keyboard after search
            hideKeyboard();
        });

        clearButton.setOnClickListener(v -> {
            programSpinner.setSelection(0);
            yearSpinner.setSelection(0);
            searchEditText.setText("");
            applyFilters("");

            // Hide keyboard after clear
            hideKeyboard();
        });

        setupProgramSpinner(programSpinner);
        setupYearSpinner(yearSpinner);
    }

    @Override
    public void onItemClick(Document document) {
        Intent intent = new Intent(this, AbstractViewActivity.class);
        intent.putExtra("DOCUMENT_ID", document.getDocumentId());
        startActivity(intent);

        // Add transition animation
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void setupRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DocumentAdapter(filteredDocuments, currentUser.getUid(), this);
        recyclerView.setAdapter(adapter);
    }

    private void loadDocuments() {
        FirebaseDatabase.getInstance().getReference("documents")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        allDocuments.clear();
                        for (DataSnapshot docSnapshot : snapshot.getChildren()) {
                            Document document = docSnapshot.getValue(Document.class);
                            if (document != null) {
                                document.setDocumentId(docSnapshot.getKey());
                                allDocuments.add(document);
                            }
                        }

                        // Apply initial filters if we have an initial query
                        if (!initialSearchQuery.isEmpty()) {
                            applyFilters(initialSearchQuery);
                        } else {
                            filteredDocuments.clear();
                            filteredDocuments.addAll(allDocuments);
                            adapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(SearchActivity.this, "Failed to load documents", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void applyFilters(String searchQuery) {
        String program = programSpinner.getSelectedItem().toString();
        String year = yearSpinner.getSelectedItem().toString();

        filteredDocuments.clear();

        for (Document document : allDocuments) {
            boolean matchesSearch = searchQuery.isEmpty() ||
                    document.getTitle().toLowerCase().contains(searchQuery.toLowerCase()) ||
                    document.getAuthors().toLowerCase().contains(searchQuery.toLowerCase()) ||
                    document.getAbstractText().toLowerCase().contains(searchQuery.toLowerCase()) ||
                    document.getKeywords().toLowerCase().contains(searchQuery.toLowerCase());

            boolean matchesProgram = program.isEmpty() ||
                    document.getProgram().equalsIgnoreCase(program);

            boolean matchesYear = year.isEmpty() ||
                    document.getYear().equalsIgnoreCase(year);

            if (matchesSearch && matchesProgram && matchesYear) {
                filteredDocuments.add(document);
            }
        }

        if (filteredDocuments.isEmpty()) {
            Toast.makeText(this, "No documents found matching your criteria", Toast.LENGTH_SHORT).show();
        }

        adapter.notifyDataSetChanged();
    }

    private void setupProgramSpinner(Spinner spinner) {
        List<String> programs = new ArrayList<>();
        programs.add(""); // Empty first option
        programs.add("BTVTE Major in Garments and Fashion Design");
        programs.add("BA in English Language Studies");
        programs.add("BA in History");
        programs.add("BA in Sociology");
        programs.add("BPA in Public Administration");
        programs.add("BS in Accountancy");
        programs.add("BS in Agricultural and Biosystems");
        programs.add("BS in Agricultural Technology");
        programs.add("BS in Agriculture Major in Animal Science");
        programs.add("BS in Agriculture Major in Crop Science");
        programs.add("BS in Applied Mathematics");
        programs.add("BS in Biology");
        programs.add("BS in Civil Engineering");
        programs.add("BS in Development Communication");
        programs.add("BS in Electrical Engineering");
        programs.add("BS in Elementary Education");
        programs.add("BS in Entrepreneurship");
        programs.add("BS in Environmental Science");
        programs.add("BS in Fisheries");
        programs.add("BS in Hospitality Management");
        programs.add("BS in Industrial Technology Major in Automotive Technology");
        programs.add("BS in Industrial Technology Major in Computer Technology");
        programs.add("BS in Industrial Technology Major in Electrical Technology");
        programs.add("BS in Industrial Technology Major in Electronics Technology");
        programs.add("BS in Information Systems");
        programs.add("BS in Information Technology");
        programs.add("BS in Mechanical Engineering");
        programs.add("BS in Office Administration");
        programs.add("BS in Physical Education");
        programs.add("BS in Secondary Education Major in English");
        programs.add("BS in Secondary Education Major in Filipino");
        programs.add("BS in Secondary Education Major in Mathematics");
        programs.add("BS in Secondary Education Major in Science");
        programs.add("BS in Secondary Education Major in Social Studies");
        programs.add("BS in Technology and Livelihood Education");
        programs.add("BSBA Major in Business Economics");
        programs.add("BSBA Major in Financial Management");
        programs.add("BSBA Major in Human Resource Management");
        programs.add("BSBA Major in Marketing Management");
        programs.add("BSEd Major in English");
        programs.add("BSEd Major in Mathematics");
        programs.add("BTVTE Major in Automotive Technology");
        programs.add("BTVTE Major in Electrical Technology");
        programs.add("BTVTE Major in Food and Service Management");
        programs.add("BTVTE Major in Garments and Fashion Design");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item,
                programs
        );
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilters(searchEditText.getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupYearSpinner(Spinner spinner) {
        List<String> years = new ArrayList<>();
        years.add(""); // Empty first option
        for (int year = 2025; year >= 1950; year--) {
            years.add(String.valueOf(year));
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.spinner_item,
                years
        );
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilters(searchEditText.getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}