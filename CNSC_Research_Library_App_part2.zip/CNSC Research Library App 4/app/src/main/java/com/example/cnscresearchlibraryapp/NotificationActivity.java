package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class NotificationActivity extends AppCompatActivity {

    private RecyclerView notificationsRecyclerView;
    private NotificationAdapter notificationAdapter;
    private List<Notification> notificationList = new ArrayList<>();
    private String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Initialize views
        ImageButton backButton = findViewById(R.id.imageButton6);
        TextView emptyView = findViewById(R.id.emptyNotificationsView);
        notificationsRecyclerView = findViewById(R.id.notificationsRecyclerView);

        // Setup RecyclerView
        notificationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        notificationAdapter = new NotificationAdapter(notificationList, this::handleNotificationAction);
        notificationsRecyclerView.setAdapter(notificationAdapter);

        // Set click listener for back button
        backButton.setOnClickListener(v -> finish());

        // Add visual feedback
        backButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setAlpha(0.5f);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setAlpha(1.0f);
                    break;
            }
            return false;
        });

        // Load notifications
        loadNotifications(emptyView);
    }

    private void loadNotifications(TextView emptyView) {
        DatabaseReference notificationsRef = FirebaseDatabase.getInstance()
                .getReference("notifications")
                .child(currentUserId);

        notificationsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                notificationList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Notification notification = snapshot.getValue(Notification.class);
                    if (notification != null) {
                        notification.setNotificationId(snapshot.getKey());
                        notificationList.add(notification);
                    }
                }

                notificationAdapter.notifyDataSetChanged();
                emptyView.setVisibility(notificationList.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(NotificationActivity.this, "Failed to load notifications", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleNotificationAction(Notification notification, String action) {
        DatabaseReference notificationRef = FirebaseDatabase.getInstance()
                .getReference("notifications")
                .child(currentUserId)
                .child(notification.getNotificationId());

        DatabaseReference documentRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(notification.getDocumentId());

        if (action.equals("approve")) {
            // Add to approved viewers
            documentRef.child("approvedViewers").child(notification.getRequesterId()).setValue(true)
                    .addOnSuccessListener(aVoid -> {
                        // Remove from access requests
                        documentRef.child("accessRequests").child(notification.getRequesterId()).removeValue();
                        // Remove notification
                        notificationRef.removeValue();
                        Toast.makeText(this, "Access approved", Toast.LENGTH_SHORT).show();
                    });
        } else if (action.equals("deny")) {
            // Remove from access requests
            documentRef.child("accessRequests").child(notification.getRequesterId()).removeValue();
            // Remove notification
            notificationRef.removeValue();
            Toast.makeText(this, "Access denied", Toast.LENGTH_SHORT).show();
        } else if (action.equals("view")) {
            // Open document view
            Intent intent = new Intent(this, AbstractViewActivity.class);
            intent.putExtra("DOCUMENT_ID", notification.getDocumentId());
            startActivity(intent);
        }
    }
}