package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AbstractViewActivity2 extends AppCompatActivity {
    private static final String TAG = "AbstractViewActivity";
    private TextView researchTitle, researchDate, abstractContent, figureCredit;
    private String documentId;
    private LinearLayout authorsLayout;
    private FirebaseAuth mAuth;
    private Document document;
    private Toast currentToast;
    private LinearLayout actionButton; // This will be hidden
    private LinearLayout authorsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abstract_view);

        mAuth = FirebaseAuth.getInstance();
        documentId = getIntent().getStringExtra("DOCUMENT_ID");
        if (documentId == null) {
            showToast("Document not found");
            finish();
            return;
        }

        initializeViews();
        loadDocument();
    }

    private void initializeViews() {
        researchTitle = findViewById(R.id.researchTitle);
        researchDate = findViewById(R.id.researchDate);
        abstractContent = findViewById(R.id.abstractContent);
        figureCredit = findViewById(R.id.figureCredit);
        authorsLayout = findViewById(R.id.authorsLayout);
        authorsContainer = findViewById(R.id.authorsContainer);

        ImageButton backButton = findViewById(R.id.imageButton2);
        backButton.setOnClickListener(v -> finish());

        // Hide the action button completely
        actionButton = findViewById(R.id.actionButton);
        actionButton.setVisibility(View.GONE); // This removes the button from layout
    }

    private void loadDocument() {
        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                document = snapshot.getValue(Document.class);
                if (document != null) {
                    displayDocumentInfo();
                } else {
                    showToast("Document not found");
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                showToast("Failed to load document");
                Log.e(TAG, "Error loading document", error.toException());
                finish();
            }
        });
    }

    private void displayDocumentInfo() {
        if (document == null) {
            showToast("Document data is invalid");
            finish();
            return;
        }

        // Set the main content views
        researchTitle.setText(document.getTitle());
        researchDate.setText("Published: " + document.getYear());
        abstractContent.setText(document.getAbstractText());
        figureCredit.setText("[Uploaded by " + document.getUploaderName() + "]");

        // Clear existing author views (but keep the static "Authors:" label)
        authorsContainer.removeAllViews();

        // Add the static "Authors:" label
        TextView authorsLabel = new TextView(this);
        authorsLabel.setText("Authors:");
        authorsLabel.setTextColor(ContextCompat.getColor(this, R.color.black));
        authorsLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        authorsLabel.setTypeface(null, Typeface.BOLD);
        authorsLabel.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        authorsContainer.addView(authorsLabel);

        // Add authors with proper formatting
        if (document.getAuthors() != null && !document.getAuthors().isEmpty()) {
            String[] authors = document.getAuthors().split("\\s*;\\s*");

            for (String author : authors) {
                author = author.trim();
                if (!author.isEmpty()) {
                    // Author bullet point
                    TextView authorName = new TextView(this);
                    authorName.setText("• " + author);
                    authorName.setTextColor(ContextCompat.getColor(this, R.color.black));
                    authorName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                    authorName.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    ));
                    authorsContainer.addView(authorName);

                    // Institution (indented)
                    TextView institution = new TextView(this);
                    institution.setText("Camarines Norte State College");
                    institution.setTextColor(ContextCompat.getColor(this, R.color.black));
                    institution.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                    institution.setPadding(dpToPx(16), 0, 0, dpToPx(8));
                    institution.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    ));
                    authorsContainer.addView(institution);
                }
            }
        } else {
            TextView noAuthors = new TextView(this);
            noAuthors.setText("No authors listed");
            noAuthors.setTextColor(ContextCompat.getColor(this, R.color.black));
            noAuthors.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            authorsContainer.addView(noAuthors);
        }
    }

    private void showToast(String message) {
        if (currentToast != null) currentToast.cancel();
        currentToast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        currentToast.show();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}