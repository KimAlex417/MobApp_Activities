package com.example.cnscresearchlibraryapp;

import android.util.Patterns;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Document implements Serializable {
    private static final long serialVersionUID = 1L;

    private String documentId;
    private String title;
    private String driveLink;
    private String program;
    private String year;
    private String authors;
    private String abstractText;
    private String uploaderName;
    private String uploaderUid;
    private Map<String, Boolean> approvedViewers = new HashMap<>();
    private Map<String, Boolean> accessRequests = new HashMap<>();
    private long createdAt;
    private long updatedAt;
    private List<String> keywords;


    // Empty constructor for Firebase
    public Document() {}

    // Constructor for creating new documents
    public Document(String title, String driveLink, String program, String year,
                    String authors, String abstractText, String uploaderName,
                    String uploaderUid) {
        this.title = title;
        this.driveLink = driveLink;
        this.program = program;
        this.year = year;
        this.authors = normalizeAuthors(authors);
        this.abstractText = abstractText;
        this.uploaderName = uploaderName;
        this.uploaderUid = uploaderUid;
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = System.currentTimeMillis();
        this.approvedViewers.put(uploaderUid, true); // Auto-approve uploader
        this.accessRequests = new HashMap<>();
    }

    // Normalize authors (e.g. remove extra commas and trim)
    private String normalizeAuthors(String authors) {
        if (authors == null || authors.isEmpty()) {
            return "";
        }
        return authors.trim()
                .replace("\n", "; ")  // Replace newlines with semicolons
                .replaceAll(";\\s*;", ";") // Remove duplicate semicolons
                .replaceAll("\\s+", " ");  // Normalize whitespace
    }



    // Firebase update helper
    public Map<String, Object> toMap() {
        Map<String, Object> result = new HashMap<>();
        result.put("documentId", documentId);
        result.put("title", title);
        result.put("driveLink", driveLink);
        result.put("program", program);
        result.put("year", year);
        result.put("authors", authors);
        result.put("abstractText", abstractText);
        result.put("uploaderName", uploaderName);
        result.put("uploaderUid", uploaderUid);
        result.put("approvedViewers", approvedViewers);
        result.put("accessRequests", accessRequests);
        result.put("createdAt", createdAt);
        result.put("updatedAt", updatedAt);
        return result;
    }

    // Add this new method for URL validation
    public boolean isValidDriveLink() {
        if (driveLink == null || driveLink.isEmpty()) {
            return false;
        }

        // Basic check for Google Drive URL pattern
        return driveLink.contains("drive.google.com") &&
                Patterns.WEB_URL.matcher(driveLink).matches();
    }


    // Getters and Setters
    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDriveLink() {
        return driveLink;
    }

    public void setDriveLink(String driveLink) {
        this.driveLink = driveLink;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getAuthors() {
        return authors != null ? authors : "";
    }

    public void setAuthors(String authors) {
        this.authors = normalizeAuthors(authors);
    }

    public String getAbstractText() {
        return abstractText != null ? abstractText : "";
    }

    public void setAbstractText(String abstractText) {
        this.abstractText = abstractText;
    }

    public String getUploaderName() {
        return uploaderName != null ? uploaderName : "";
    }

    public void setUploaderName(String uploaderName) {
        this.uploaderName = uploaderName;
    }

    public String getUploaderUid() {
        return uploaderUid != null ? uploaderUid : "";
    }

    public void setUploaderUid(String uploaderUid) {
        this.uploaderUid = uploaderUid;
    }

    public Map<String, Boolean> getApprovedViewers() {
        if (approvedViewers == null) {
            approvedViewers = new HashMap<>();
        }
        return approvedViewers;
    }

    public void setApprovedViewers(Map<String, Boolean> approvedViewers) {
        this.approvedViewers = approvedViewers != null ? approvedViewers : new HashMap<>();
    }

    public Map<String, Boolean> getAccessRequests() {
        if (accessRequests == null) {
            accessRequests = new HashMap<>();
        }
        return accessRequests;
    }

    public void setAccessRequests(Map<String, Boolean> accessRequests) {
        this.accessRequests = accessRequests != null ? accessRequests : new HashMap<>();
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(long updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Check if user has approved access
    public boolean hasAccess(String userId) {
        return approvedViewers != null && approvedViewers.containsKey(userId);
    }

    // Check if user has requested access
    public boolean hasRequestedAccess(String userId) {
        return accessRequests != null && accessRequests.containsKey(userId);
    }

    // Return authors as array
    public String[] getAuthorsArray() {
        if (authors == null || authors.isEmpty()) {
            return new String[0];
        }
        return authors.split("\\s*;\\s*");


    }
    // Getter for keywords
    public String getKeywords() {
        if (keywords == null || keywords.isEmpty()) {
            return "";  // Return empty string if no keywords
        }
        // Convert list of keywords to comma-separated string
        return String.join(", ", keywords);
    }

    // Setter for keywords
    public void setKeywords(List<String> keywords) {
        this.keywords = keywords;
    }


}
