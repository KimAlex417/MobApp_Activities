package com.example.cnscresearchlibraryapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AbstractUploadActivity extends AppCompatActivity {
    private static final String TAG = "AbstractUploadActivity";

    private TextView researchTitle, researchDate, abstractContent, figureCredit;
    private String documentId;
    private LinearLayout authorsContainer;
    private String driveLink;
    private Toast currentToast;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;
    private FirebaseAnalytics firebaseAnalytics;
    private Document currentDocument;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abstract_upload);

        mAuth = FirebaseAuth.getInstance();
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        documentId = getIntent().getStringExtra("DOCUMENT_ID");

        if (documentId == null) {
            showToast("Document not found");
            finish();
            return;
        }

        initializeViews();
        verifyAndLoadDocument();
    }

    private void initializeViews() {
        researchTitle = findViewById(R.id.researchTitle);
        researchDate = findViewById(R.id.researchDate);
        abstractContent = findViewById(R.id.abstractContent);
        figureCredit = findViewById(R.id.figureCredit);
        authorsContainer = findViewById(R.id.authorsLayout);

        ImageButton backButton = findViewById(R.id.imageButton2);
        backButton.setOnClickListener(v -> finish());

        LinearLayout accessPdfLayout = findViewById(R.id.accessPdfLayout);
        accessPdfLayout.setOnClickListener(v -> {
            if (currentDocument != null && currentDocument.getDriveLink() != null && !currentDocument.getDriveLink().isEmpty()) {
                openDriveDocument(currentDocument.getDriveLink());
            } else {
                showToast("Document link not available");
                Log.e(TAG, "Drive link is null or empty");
            }
        });

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading document...");
        progressDialog.setCancelable(false);
    }

    private void verifyAndLoadDocument() {
        progressDialog.show();

        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }

                if (!snapshot.exists()) {
                    showToast("Document not found");
                    finish();
                    return;
                }

                String uploaderUid = snapshot.child("uploaderUid").getValue(String.class);
                Boolean isApprovedViewer = snapshot.child("approvedViewers")
                        .child(mAuth.getCurrentUser().getUid()).getValue(Boolean.class);

                if (mAuth.getCurrentUser() != null &&
                        (mAuth.getCurrentUser().getUid().equals(uploaderUid) ||
                                (isApprovedViewer != null && isApprovedViewer))) {

                    currentDocument = snapshot.getValue(Document.class);
                    if (currentDocument == null) {
                        showToast("Failed to parse document data");
                        finish();
                        return;
                    }

                    // Debug logging for drive link
                    Log.d(TAG, "Retrieved drive link: " + currentDocument.getDriveLink());
                    Log.d(TAG, "Complete document data: " + snapshot.getValue());

                    displayDocumentInfo(currentDocument);

                    // Log analytics event
                    Bundle bundle = new Bundle();
                    bundle.putString("document_id", documentId);
                    bundle.putString("document_title", currentDocument.getTitle());
                    firebaseAnalytics.logEvent("document_view", bundle);
                } else {
                    showToast("You don't have permission to view this document");
                    finish();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
                showToast("Failed to load document: " + error.getMessage());
                Log.e(TAG, "Database error: ", error.toException());
                finish();
            }
        });
    }

    private void openDriveDocument(String link) {
        if (link == null || link.isEmpty()) {
            showToast("Document link not available");
            Log.e(TAG, "Empty drive link provided");
            return;
        }

        Log.d(TAG, "Original drive link: " + link);

        if (!isValidDriveLink(link)) {
            showToast("Invalid Google Drive link");
            Log.e(TAG, "Invalid drive link format");
            return;
        }

        String normalizedLink = normalizeDriveLink(link);
        Log.d(TAG, "Normalized drive link: " + normalizedLink);

        try {
            Uri uri = Uri.parse(normalizedLink);

            // Log access event
            Bundle bundle = new Bundle();
            bundle.putString("document_id", documentId);
            bundle.putString("document_title", currentDocument.getTitle());
            firebaseAnalytics.logEvent("document_access", bundle);

            // Create both Custom Tabs and regular intent
            CustomTabsIntent customTabsIntent = new CustomTabsIntent.Builder()
                    .setToolbarColor(ContextCompat.getColor(this, R.color.maroon))
                    .setShowTitle(true)
                    .setStartAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                    .setExitAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                    .build();

            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);

            // Create chooser intent
            Intent chooserIntent = Intent.createChooser(browserIntent, "Open PDF with");
            // Add Custom Tabs as an option
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { customTabsIntent.intent });

            startActivity(chooserIntent);
        } catch (Exception e) {
            showToast("Error opening document");
            Log.e(TAG, "Error opening drive link", e);
        }
    }

    private boolean isValidDriveLink(String url) {
        return url != null &&
                (url.contains("drive.google.com") ||
                        url.contains("docs.google.com") ||
                        url.contains("storage.googleapis.com"));
    }

    private String normalizeDriveLink(String originalLink) {
        if (originalLink == null) return null;

        // If it's a sharing link, convert to direct download if possible
        if (originalLink.contains("drive.google.com/file/d/")) {
            String[] parts = originalLink.split("/file/d/");
            if (parts.length > 1) {
                String fileId = parts[1].split("/")[0];
                return "https://drive.google.com/uc?export=download&id=" + fileId;
            }
        }

        return originalLink;
    }

    private void displayDocumentInfo(Document document) {
        if (document == null) {
            showToast("Document data is invalid");
            finish();
            return;
        }

        researchTitle.setText(document.getTitle());
        researchDate.setText("Published: " + document.getYear());
        abstractContent.setText(document.getAbstractText());
        figureCredit.setText("[Uploaded by " + document.getUploaderName() + "]");

        // Set drive link from document
        driveLink = document.getDriveLink();
        Log.d(TAG, "Displaying document with drive link: " + driveLink);

        authorsContainer.removeAllViews();
        TextView authorsLabel = new TextView(this);
        authorsLabel.setText("Authors:");
        authorsLabel.setTextColor(ContextCompat.getColor(this, R.color.black));
        authorsLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        authorsLabel.setTypeface(null, Typeface.BOLD);
        authorsContainer.addView(authorsLabel);

        if (document.getAuthors() != null && !document.getAuthors().isEmpty()) {
            String[] authors = document.getAuthors().split(",(?![^,]*,)");
            for (String author : authors) {
                author = author.trim();
                if (!author.isEmpty()) {
                    addAuthorWithInstitution(author);
                }
            }
        } else {
            TextView noAuthors = new TextView(this);
            noAuthors.setText("No authors listed");
            noAuthors.setTextColor(ContextCompat.getColor(this, R.color.black));
            authorsContainer.addView(noAuthors);
        }
    }

    private void addAuthorWithInstitution(String authorName) {
        TextView authorView = new TextView(this);
        authorView.setText("• " + authorName);
        authorView.setTextColor(ContextCompat.getColor(this, R.color.black));
        authorView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        authorsContainer.addView(authorView);

        TextView institution = new TextView(this);
        institution.setText("Camarines Norte State College");
        institution.setTextColor(ContextCompat.getColor(this, R.color.black));
        institution.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        authorsContainer.addView(institution);
    }

    private void showToast(String message) {
        if (currentToast != null) currentToast.cancel();
        currentToast = Toast.makeText(this, message, Toast.LENGTH_SHORT);
        currentToast.show();
    }

    @Override
    protected void onDestroy() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        super.onDestroy();
    }
}