package com.example.cnscresearchlibraryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // CORRECT: Use the back button (imageButton2 from your XML)
        ImageButton backButton = findViewById(R.id.imageButton2);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(AboutActivity.this, MainActivity.class);
            intent.putExtra("SHOW_SIDE_MENU", true);
            startActivity(intent);
            finish();
        });
    }
}