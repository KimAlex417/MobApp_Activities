package com.example.cnscresearchlibraryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

public class HelpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // Back button functionality
        ImageButton backButton = findViewById(R.id.imageButton2); // Use your back button ID
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(HelpActivity.this, MainActivity.class);
            intent.putExtra("SHOW_SIDE_MENU", true);
            startActivity(intent);
            finish();
        });
    }
}