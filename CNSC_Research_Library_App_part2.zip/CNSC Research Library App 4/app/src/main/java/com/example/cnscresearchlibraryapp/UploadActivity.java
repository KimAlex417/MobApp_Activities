package com.example.cnscresearchlibraryapp;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UploadActivity extends AppCompatActivity {

    private EditText titleInput, driveLinkInput, authorsInput, abstractInput, uploaderNameInput;
    private Spinner programSpinner, yearLevelSpinner;
    private Button uploadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        initializeViews();
        setupBackButton();
        setupSpinners();
        setupUploadButton();
    }

    private void initializeViews() {
        titleInput = findViewById(R.id.TitleEditText);
        driveLinkInput = findViewById(R.id.DriveLinkEditText);
        authorsInput = findViewById(R.id.AuthorsEditText);
        abstractInput = findViewById(R.id.AbstractEditText);
        uploaderNameInput = findViewById(R.id.UploaderNameEditText);

        programSpinner = findViewById(R.id.ProgramSpinner);
        yearLevelSpinner = findViewById(R.id.yearPublicationSpinner);
        uploadButton = findViewById(R.id.UploadButton);
    }

    private void setupBackButton() {
        ImageButton backButton = findViewById(R.id.BackButton);
        backButton.setOnClickListener(v -> finish());

        backButton.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.setAlpha(0.5f);
            } else if (event.getAction() == MotionEvent.ACTION_UP ||
                    event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.setAlpha(1.0f);
            }
            return false;
        });
    }

    private void setupSpinners() {
        ArrayAdapter<String> programAdapter = new ArrayAdapter<>(
                this, R.layout.spinner_item, getProgramList());
        programAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        programSpinner.setAdapter(programAdapter);

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(
                this, R.layout.spinner_item, getYearList());
        yearAdapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        yearLevelSpinner.setAdapter(yearAdapter);
    }

    private List<String> getProgramList() {
        List<String> programs = new ArrayList<>();
        programs.add("Select Program");
        programs.add("BA in English Language Studies");
        programs.add("BA in History");
        programs.add("BA in Sociology");
        programs.add("BPA in Public Administration");
        programs.add("BS in Accountancy");
        programs.add("BS in Agricultural and Biosystems");
        programs.add("BS in Agricultural Technology");
        programs.add("BS in Agriculture Major in Animal Science");
        programs.add("BS in Agriculture Major in Crop Science");
        programs.add("BS in Applied Mathematics");
        programs.add("BS in Biology");
        programs.add("BS in Civil Engineering");
        programs.add("BS in Development Communication");
        programs.add("BS in Electrical Engineering");
        programs.add("BS in Elementary Education");
        programs.add("BS in Entrepreneurship");
        programs.add("BS in Environmental Science");
        programs.add("BS in Fisheries");
        programs.add("BS in Hospitality Management");
        programs.add("BS in Industrial Technology Major in Automotive Technology");
        programs.add("BS in Industrial Technology Major in Computer Technology");
        programs.add("BS in Industrial Technology Major in Electrical Technology");
        programs.add("BS in Industrial Technology Major in Electronics Technology");
        programs.add("BS in Information Systems");
        programs.add("BS in Information Technology");
        programs.add("BS in Mechanical Engineering");
        programs.add("BS in Office Administration");
        programs.add("BS in Physical Education");
        programs.add("BS in Secondary Education Major in English");
        programs.add("BS in Secondary Education Major in Filipino");
        programs.add("BS in Secondary Education Major in Mathematics");
        programs.add("BS in Secondary Education Major in Science");
        programs.add("BS in Secondary Education Major in Social Studies");
        programs.add("BS in Technology and Livelihood Education");
        programs.add("BSBA Major in Business Economics");
        programs.add("BSBA Major in Financial Management");
        programs.add("BSBA Major in Human Resource Management");
        programs.add("BSBA Major in Marketing Management");
        programs.add("BSEd Major in English");
        programs.add("BSEd Major in Mathematics");
        programs.add("BTVTE Major in Automotive Technology");
        programs.add("BTVTE Major in Electrical Technology");
        programs.add("BTVTE Major in Food and Service Management");
        programs.add("BTVTE Major in Garments and Fashion Design");
        return programs;
    }

    private List<String> getYearList() {
        List<String> years = new ArrayList<>();
        years.add("Select Year");
        for (int year = 2025; year >= 1950; year--) {
            years.add(String.valueOf(year));
        }
        return years;
    }

    private void setupUploadButton() {
        uploadButton.setOnClickListener(v -> {
            if (validateInputs()) {
                uploadDocument();
            }
        });
    }

    private boolean validateInputs() {
        if (titleInput.getText().toString().trim().isEmpty()) {
            titleInput.setError("Title is required");
            return false;
        }
        if (driveLinkInput.getText().toString().trim().isEmpty()) {
            driveLinkInput.setError("Drive link is required");
            return false;
        }
        if (!isValidDriveLink(driveLinkInput.getText().toString().trim())) {
            driveLinkInput.setError("Invalid Google Drive link");
            return false;
        }
        if (programSpinner.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select a program", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (yearLevelSpinner.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select year level", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (authorsInput.getText().toString().trim().isEmpty()) {
            authorsInput.setError("Authors are required");
            return false;
        }
        if (uploaderNameInput.getText().toString().trim().isEmpty()) {
            uploaderNameInput.setError("Your name is required");
            return false;
        }
        return true;
    }

    private void uploadDocument() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Not logged in!", Toast.LENGTH_SHORT).show();
            return;
        }

        uploadButton.setEnabled(false);

        String title = titleInput.getText().toString().trim();
        String driveLink = driveLinkInput.getText().toString().trim();
        String program = programSpinner.getSelectedItem().toString();
        String yearLevel = yearLevelSpinner.getSelectedItem().toString();
        String authors = authorsInput.getText().toString().trim();
        String abstractText = abstractInput.getText().toString().trim();
        String uploaderName = uploaderNameInput.getText().toString().trim();
        String uploaderUid = user.getUid();

        Document document = new Document();
        document.setTitle(title);
        document.setDriveLink(driveLink);
        document.setProgram(program);
        document.setYear(yearLevel);
        document.setAuthors(authors);
        document.setAbstractText(abstractText);
        document.setUploaderName(uploaderName);
        document.setUploaderUid(uploaderUid);
        document.setCreatedAt(System.currentTimeMillis());
        document.setUpdatedAt(System.currentTimeMillis());

        Map<String, Boolean> approvedViewers = new HashMap<>();
        approvedViewers.put(uploaderUid, true);
        document.setApprovedViewers(approvedViewers);
        document.setAccessRequests(new HashMap<>());

        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("documents");
        String documentId = dbRef.push().getKey();

        dbRef.child(documentId).setValue(document.toMap())
                .addOnSuccessListener(aVoid -> {
                    FirebaseDatabase.getInstance().getReference("user_uploads")
                            .child(uploaderUid)
                            .child(documentId)
                            .setValue(true)
                            .addOnCompleteListener(task -> {
                                Toast.makeText(UploadActivity.this, "Upload successful!", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e("UploadError", "Error details: ", e);
                    uploadButton.setEnabled(true);
                });
    }

    private boolean isValidDriveLink(String url) {
        return url.startsWith("https://drive.google.com/") || url.startsWith("https://docs.google.com/");
    }
}
