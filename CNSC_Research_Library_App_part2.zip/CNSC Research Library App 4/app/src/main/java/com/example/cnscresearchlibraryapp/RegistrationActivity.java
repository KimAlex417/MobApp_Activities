package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class RegistrationActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private DatabaseReference databaseReference;
    private EditText emailEditText, passwordEditText;
    private Spinner courseSpinner, yearSpinner;
    private String selectedCourse = "";
    private String selectedYear = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        auth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button registerButton = findViewById(R.id.RegisterButton);
        TextView loginLink = findViewById(R.id.textViewLoginLink);
        courseSpinner = findViewById(R.id.courseSpinner);
        yearSpinner = findViewById(R.id.yearSpinner2);

        setupSpinners();

        registerButton.setOnClickListener(v -> registerUser());

        loginLink.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void setupSpinners() {
        // Course spinner setup
        List<String> courses = new ArrayList<>();
        courses.add("Select Program");
        courses.add("Select Course"); // Default first item
        courses.add("BTVTE Major in Garments and Fashion Design");
        courses.add("BA in English Language Studies");
        courses.add("BA in History");
        courses.add("BA in Sociology");
        courses.add("BPA in Public Administration");
        courses.add("BS in Accountancy");
        courses.add("BS in Agricultural and Biosystems");
        courses.add("BS in Agricultural Technology");
        courses.add("BS in Agriculture Major in Animal Science");
        courses.add("BS in Agriculture Major in Crop Science");
        courses.add("BS in Applied Mathematics");
        courses.add("BS in Biology");
        courses.add("BS in Civil Engineering");
        courses.add("BS in Development Communication");
        courses.add("BS in Electrical Engineering");
        courses.add("BS in Elementary Education");
        courses.add("BS in Entrepreneurship");
        courses.add("BS in Environmental Science");
        courses.add("BS in Fisheries");
        courses.add("BS in Hospitality Management");
        courses.add("BS in Industrial Technology Major in Automotive Technology");
        courses.add("BS in Industrial Technology Major in Computer Technology");
        courses.add("BS in Industrial Technology Major in Electrical Technology");
        courses.add("BS in Industrial Technology Major in Electronics Technology");
        courses.add("BS in Information Systems");
        courses.add("BS in Information Technology");
        courses.add("BS in Mechanical Engineering");
        courses.add("BS in Office Administration");
        courses.add("BS in Physical Education");
        courses.add("BS in Secondary Education Major in English");
        courses.add("BS in Secondary Education Major in Filipino");
        courses.add("BS in Secondary Education Major in Mathematics");
        courses.add("BS in Secondary Education Major in Science");
        courses.add("BS in Secondary Education Major in Social Studies");
        courses.add("BS in Technology and Livelihood Education");
        courses.add("BSBA Major in Business Economics");
        courses.add("BSBA Major in Financial Management");
        courses.add("BSBA Major in Human Resource Management");
        courses.add("BSBA Major in Marketing Management");
        courses.add("BSEd Major in English");
        courses.add("BSEd Major in Mathematics");
        courses.add("BTVTE Major in Automotive Technology");
        courses.add("BTVTE Major in Electrical Technology");
        courses.add("BTVTE Major in Food and Service Management");

        ArrayAdapter<String> courseAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, courses);
        courseSpinner.setAdapter(courseAdapter);
        courseSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCourse = position > 0 ? parent.getItemAtPosition(position).toString() : "";
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Year spinner setup
        List<String> years = new ArrayList<>();
        years.add("Select Year Level");
        years.add("1st Year");
        years.add("2nd Year");
        years.add("3rd Year");
        years.add("4th Year");

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, years);
        yearSpinner.setAdapter(yearAdapter);
        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedYear = position > 0 ? parent.getItemAtPosition(position).toString() : "";
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void registerUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedCourse.isEmpty() || selectedYear.isEmpty()) {
            Toast.makeText(this, "Please select your course and year level", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(email.split("@")[0])
                                    .build();

                            firebaseUser.updateProfile(profileUpdates)
                                    .addOnCompleteListener(profileTask -> {
                                        if (profileTask.isSuccessful()) {
                                            User user = new User(
                                                    email.split("@")[0],
                                                    email,
                                                    selectedCourse,
                                                    selectedYear
                                            );

                                            databaseReference.child(firebaseUser.getUid())
                                                    .setValue(user)
                                                    .addOnCompleteListener(dbTask -> {
                                                        if (dbTask.isSuccessful()) {
                                                            // First go to MainActivity
                                                            Intent mainIntent = new Intent(RegistrationActivity.this, MainActivity.class);
                                                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                                            startActivity(mainIntent);

                                                            // Then open appropriate profile
                                                            if (UserUtils.isJuniorStudent(selectedYear)) {
                                                                startActivity(new Intent(RegistrationActivity.this, ProfileActivity2.class));
                                                            } else {
                                                                startActivity(new Intent(RegistrationActivity.this, ProfileActivity.class));
                                                            }
                                                            finish();
                                                        }
                                                    });
                                        }
                                    });
                        }
                    }
                });
    }
}