package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ProfileActivity2 extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DocumentAdapter adapter;
    private List<Document> documentList = new ArrayList<>();
    private TextView userNameTextView;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile2);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        initializeViews();
        setupRecyclerView();
        loadUserProfile();
        setupButtonListeners();

        loadSavedDocuments();
    }

    private void initializeViews() {
        userNameTextView = findViewById(R.id.textView14);
        recyclerView = findViewById(R.id.recyclerView);

        // Back button
        ImageButton backButton = findViewById(R.id.imageButton6);
        backButton.setOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Updated adapter initialization with click listener
        adapter = new DocumentAdapter(documentList, currentUser.getUid(), document -> {
            Intent intent = new Intent(ProfileActivity2.this, DocumentViewerActivity.class);
            intent.putExtra("DOCUMENT_ID", document.getDocumentId());
            intent.putExtra("IS_OWNER", false); // For saved documents, user is never owner
            startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
    }

    private void loadUserProfile() {
        if (currentUser != null) {
            String displayName = currentUser.getDisplayName() != null ?
                    currentUser.getDisplayName() : "User";
            userNameTextView.setText("Name: " + displayName);
        }
    }

    private void setupButtonListeners() {
        // No additional buttons needed in this simplified version
    }

    private void loadSavedDocuments() {
        DatabaseReference savedRef = FirebaseDatabase.getInstance()
                .getReference("savedDocuments")
                .child(currentUser.getUid());

        savedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                documentList.clear();
                for (DataSnapshot docSnapshot : snapshot.getChildren()) {
                    String documentId = docSnapshot.getKey();
                    fetchDocumentDetails(documentId);
                }

                if (!snapshot.exists()) {
                    Toast.makeText(ProfileActivity2.this,
                            "No saved documents yet", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity2.this,
                        "Failed to load saved documents", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchDocumentDetails(String documentId) {
        DatabaseReference docRef = FirebaseDatabase.getInstance()
                .getReference("documents")
                .child(documentId);

        docRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Document document = snapshot.getValue(Document.class);
                if (document != null) {
                    document.setDocumentId(documentId);
                    documentList.add(document);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ProfileActivity2", "Error loading document details", error.toException());
            }
        });
    }
}