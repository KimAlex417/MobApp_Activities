package com.example.cnscresearchlibraryapp;

public class Notification {
    private String title;
    private String message;
    private String documentId;
    private String requesterId;
    private String notificationId;

    public Notification() {}

    public Notification(String title, String message, String documentId, String requesterId) {
        this.title = title;
        this.message = message;
        this.documentId = documentId;
        this.requesterId = requesterId;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public String getMessage() { return message; }
    public String getDocumentId() { return documentId; }
    public String getRequesterId() { return requesterId; }
    public String getNotificationId() { return notificationId; }
    public void setNotificationId(String notificationId) { this.notificationId = notificationId; }
}