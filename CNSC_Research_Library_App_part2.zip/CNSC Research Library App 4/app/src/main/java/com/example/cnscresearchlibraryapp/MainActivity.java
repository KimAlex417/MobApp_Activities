package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout sideMenu;
    private View overlay;
    private boolean isMenuShown = false;
    private Animation slideInRight, slideOutRight;
    private FirebaseAuth auth;
    private DatabaseReference userRef;
    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        auth = FirebaseAuth.getInstance();
        userRef = FirebaseDatabase.getInstance().getReference("users");

        // Check if user is logged in
        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Initialize views
        initializeViews();
        setupButtonClickListeners();
        setupSideMenu();
        setupSearchFunctionality();
    }

    private void initializeViews() {
        sideMenu = findViewById(R.id.sideMenu);
        overlay = findViewById(R.id.overlay);
        searchEditText = findViewById(R.id.editText);

        // Debug check for layout inflation
        if (sideMenu == null || overlay == null || searchEditText == null) {
            Toast.makeText(this, "Critical views not found!", Toast.LENGTH_LONG).show();
            Log.e("DEBUG", "Side menu: " + (sideMenu != null) +
                    ", Overlay: " + (overlay != null) +
                    ", SearchEditText: " + (searchEditText != null));
            return;
        }

        // Initialize animations
        slideInRight = AnimationUtils.loadAnimation(this, R.anim.slide_in_right);
        slideOutRight = AnimationUtils.loadAnimation(this, R.anim.slide_out_right);

        // Initially hide the side menu and overlay
        sideMenu.setVisibility(View.GONE);
        overlay.setVisibility(View.GONE);
    }

    private void setupButtonClickListeners() {
        // Map of button IDs to their search terms
        Map<Integer, String> buttonSearchTerms = new HashMap<>();
        buttonSearchTerms.put(R.id.Database, "Database");
        buttonSearchTerms.put(R.id.Mathematics, "Mathematics");
        buttonSearchTerms.put(R.id.Mobile, "Mobile Development");
        buttonSearchTerms.put(R.id.Robotics, "Robotics");
        buttonSearchTerms.put(R.id.Mental_Health, "Mental Health");
        buttonSearchTerms.put(R.id.Marketing, "Marketing");
        buttonSearchTerms.put(R.id.Ai, "Artificial Intelligence");
        buttonSearchTerms.put(R.id.System, "System Design");

        // Set click listeners for all category buttons
        for (Map.Entry<Integer, String> entry : buttonSearchTerms.entrySet()) {
            ImageButton button = findViewById(entry.getKey());
            if (button != null) {
                button.setOnClickListener(v -> {
                    // Set search term and perform search
                    String searchTerm = entry.getValue();
                    searchEditText.setText(searchTerm);
                    performSearch(searchTerm);

                    // Optional: Add button press animation
                    animateButtonPress(button);
                });
            }
        }
    }

    private void setupSideMenu() {
        ImageButton menuButton = findViewById(R.id.imageView44);
        ImageButton closeButton = sideMenu.findViewById(R.id.btnCloseMenu);
        Button profileButton = sideMenu.findViewById(R.id.button);
        Button settingsButton = sideMenu.findViewById(R.id.button2);
        Button aboutButton = sideMenu.findViewById(R.id.button3);
        Button logoutButton = sideMenu.findViewById(R.id.button5);
        Button helpButton = sideMenu.findViewById(R.id.button4);

        // Set click listeners for menu items
        if (menuButton != null) menuButton.setOnClickListener(v -> toggleSideMenu());
        if (closeButton != null) closeButton.setOnClickListener(v -> toggleSideMenu());
        if (overlay != null) overlay.setOnClickListener(v -> toggleSideMenu());

        // Profile button with year level check
        if (profileButton != null) {
            profileButton.setOnClickListener(v -> {
                if (isMenuShown) toggleSideMenu();
                checkYearLevelAndOpenProfile();
            });
        }

        // Other menu buttons
        if (settingsButton != null) {
            settingsButton.setOnClickListener(v -> {
                if (isMenuShown) toggleSideMenu();
                navigateToActivity(SettingActivity.class);
            });
        }

        if (aboutButton != null) {
            aboutButton.setOnClickListener(v -> {
                if (isMenuShown) toggleSideMenu();
                navigateToActivity(AboutActivity.class);
            });
        }

        if (helpButton != null) {
            helpButton.setOnClickListener(v -> {
                if (isMenuShown) toggleSideMenu();
                navigateToActivity(HelpActivity.class);
            });
        }

        if (logoutButton != null) {
            logoutButton.setOnClickListener(v -> {
                auth.signOut();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            });
        }
    }

    private void setupSearchFunctionality() {
        if (searchEditText != null) {
            searchEditText.setOnClickListener(v -> {
                navigateToActivity(SearchActivity.class);
            });

            // Prevent keyboard from opening when EditText is clicked
            searchEditText.setFocusable(false);
            searchEditText.setClickable(true);
        }
    }

    private void performSearch(String query) {
        // Show feedback that search is being performed
        Toast.makeText(this, "Searching for: " + query, Toast.LENGTH_SHORT).show();

        // Navigate to SearchActivity with the search query
        Intent searchIntent = new Intent(MainActivity.this, SearchActivity.class);
        searchIntent.putExtra("SEARCH_QUERY", query);
        startActivity(searchIntent);

        // Optional: Add transition animation
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void animateButtonPress(View button) {
        Animation shrinkAnimation = AnimationUtils.loadAnimation(this, R.anim.button_scale_down);
        Animation growAnimation = AnimationUtils.loadAnimation(this, R.anim.button_scale_up);

        shrinkAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                button.startAnimation(growAnimation);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });

        button.startAnimation(shrinkAnimation);
    }

    private void checkYearLevelAndOpenProfile() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        userRef.child(user.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userData = snapshot.getValue(User.class);
                if (userData != null) {
                    Intent profileIntent;
                    if (UserUtils.isJuniorStudent(userData.getYear())) {
                        profileIntent = new Intent(MainActivity.this, ProfileActivity2.class);
                    } else {
                        profileIntent = new Intent(MainActivity.this, ProfileActivity.class);
                    }
                    startActivity(profileIntent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Failed to load user data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateToActivity(Class<?> activityClass) {
        try {
            startActivity(new Intent(this, activityClass));
        } catch (Exception e) {
            Toast.makeText(this, "Error opening activity", Toast.LENGTH_SHORT).show();
            Log.e("NAVIGATION", "Failed to start activity", e);
        }
    }

    private void toggleSideMenu() {
        if (isMenuShown) {
            // Set up the slide-out animation with a listener
            slideOutRight.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    // Optional: Do something on start
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    // Hide the menu after animation completes
                    sideMenu.setVisibility(View.GONE);
                    overlay.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                    // Not used
                }
            });
            sideMenu.startAnimation(slideOutRight);
        } else {
            // Remove any existing listeners to avoid conflicts
            slideInRight.setAnimationListener(null);

            // Show and animate the menu in
            sideMenu.setVisibility(View.VISIBLE);
            overlay.setVisibility(View.VISIBLE);
            sideMenu.startAnimation(slideInRight);
        }
        isMenuShown = !isMenuShown;
    }

    @Override
    public void onBackPressed() {
        if (isMenuShown) {
            toggleSideMenu();
        } else {
            super.onBackPressed();
        }
    }
}