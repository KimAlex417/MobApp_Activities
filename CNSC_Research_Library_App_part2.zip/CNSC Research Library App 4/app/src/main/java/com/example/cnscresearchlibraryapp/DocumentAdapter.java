package com.example.cnscresearchlibraryapp;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.List;

public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.DocumentViewHolder> {
    private List<Document> documentList;
    private String currentUserId;
    private DatabaseReference savedRef;
    private DatabaseReference usersRef;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Document document);
    }

    public DocumentAdapter(List<Document> documentList, String currentUserId, OnItemClickListener listener) {
        this.documentList = documentList;
        this.currentUserId = currentUserId;
        this.listener = listener;
        this.savedRef = FirebaseDatabase.getInstance().getReference("savedDocuments").child(currentUserId);
        this.usersRef = FirebaseDatabase.getInstance().getReference("users");
    }

    @NonNull
    @Override
    public DocumentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_document, parent, false);
        return new DocumentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DocumentViewHolder holder, int position) {
        Document document = documentList.get(position);
        boolean isOwner = currentUserId != null && currentUserId.equals(document.getUploaderUid());

        holder.titleTextView.setText(document.getTitle());
        holder.yearTextView.setText("Year: " + document.getYear());
        holder.programTextView.setText("Program: " + document.getProgram());
        holder.authorsTextView.setText("Authors: " + document.getAuthors());

        updateBookmarkIcon(holder, document.getDocumentId());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(document);
            }
        });

        holder.viewButton.setOnClickListener(v -> {
            openDocumentBasedOnUserYear(v, document, isOwner);
        });

        holder.bookmarkButton.setOnClickListener(v -> {
            toggleBookmark(document.getDocumentId(), holder);
        });
    }

    private void openDocumentBasedOnUserYear(View view, Document document, boolean isOwner) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) return;

        usersRef.child(currentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                if (user != null) {
                    Intent intent;
                    if (UserUtils.isJuniorStudent(user.getYear())) {
                        intent = new Intent(view.getContext(), AbstractViewActivity2.class);
                    } else {
                        intent = new Intent(view.getContext(), AbstractViewActivity.class);
                        intent.putExtra("IS_OWNER", isOwner);
                    }
                    intent.putExtra("DOCUMENT_ID", document.getDocumentId());
                    view.getContext().startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(view.getContext(), "Failed to load user data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateBookmarkIcon(DocumentViewHolder holder, String documentId) {
        savedRef.child(documentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    holder.bookmarkButton.setImageResource(R.drawable.baseline_bookmark_24_filled);
                } else {
                    holder.bookmarkButton.setImageResource(R.drawable.baseline_bookmark_24);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("DocumentAdapter", "Error checking bookmark", error.toException());
            }
        });
    }

    private void toggleBookmark(String documentId, DocumentViewHolder holder) {
        savedRef.child(documentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    savedRef.child(documentId).removeValue();
                    holder.bookmarkButton.setImageResource(R.drawable.baseline_bookmark_24);
                    Toast.makeText(holder.itemView.getContext(),
                            "Document removed from saved", Toast.LENGTH_SHORT).show();
                } else {
                    savedRef.child(documentId).setValue(true);
                    holder.bookmarkButton.setImageResource(R.drawable.baseline_bookmark_24_filled);
                    Toast.makeText(holder.itemView.getContext(),
                            "Document saved", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(holder.itemView.getContext(),
                        "Failed to update bookmark", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return documentList.size();
    }

    public static class DocumentViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, yearTextView, programTextView, authorsTextView;
        Button viewButton;
        ImageButton bookmarkButton;

        public DocumentViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            yearTextView = itemView.findViewById(R.id.yearTextView);
            programTextView = itemView.findViewById(R.id.programTextView);
            authorsTextView = itemView.findViewById(R.id.authorsTextView);
            viewButton = itemView.findViewById(R.id.viewButton);
            bookmarkButton = itemView.findViewById(R.id.bookmarkButton);
        }
    }
}