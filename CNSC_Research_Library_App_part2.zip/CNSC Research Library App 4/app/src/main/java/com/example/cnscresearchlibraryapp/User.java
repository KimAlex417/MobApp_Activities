package com.example.cnscresearchlibraryapp;

public class User {
    private String username;
    private String email;
    private String course;
    private String year;

    // Default constructor required for Firebase
    public User() {
    }

    public User(String username, String email, String course, String year) {
        this.username = username;
        this.email = email;
        this.course = course;
        this.year = year;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}